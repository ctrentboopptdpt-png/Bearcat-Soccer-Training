const cacheName = "off-season-soccer-training-v4";
const appShell = [
  "./",
  "./index.html",
  "./offseason-training.html",
  "./offseason-training.css?v=2026-05-13-visuals",
  "./offseason-training.js?v=2026-05-13-visuals",
  "./assets/hero-soccer-culture-kit.png?v=2026-05-13-visuals",
  "./assets/spencerville-bearcats-soccer.png?v=2026-05-13-visuals",
  "./assets/training-app-icon.svg",
  "./site.webmanifest?v=2026-05-13-visuals",
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(caches.open(cacheName).then((cache) => cache.addAll(appShell)));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== cacheName).map((key) => caches.delete(key))).then(() =>
        self.clients.claim()
      )
    )
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin) return;

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response.ok) {
          const responseToCache = response.clone();
          caches.open(cacheName).then((cache) => cache.put(event.request, responseToCache));
        }
        return response;
      })
      .catch(() =>
        caches.match(event.request).then((cached) => {
          if (cached) return cached;
          if (event.request.mode === "navigate") return caches.match("./index.html");
          return Response.error();
        })
      )
  );
});
